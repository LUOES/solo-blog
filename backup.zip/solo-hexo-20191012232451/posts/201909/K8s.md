title: K8s
date: '2019-09-15 20:31:44'
updated: '2019-09-15 20:31:44'
tags: [K8s]
permalink: /articles/2019/09/15/1568550704215.html
---
![](https://img.hacpai.com/bing/20181230.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

环境搭建
