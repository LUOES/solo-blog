title: swoole coroutine 相关参数
date: '2019-09-16 14:28:55'
updated: '2019-09-16 16:38:05'
tags: [swoole]
permalink: /articles/2019/09/16/1568615335172.html
---
![](https://img.hacpai.com/bing/20180508.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

# corotine 
## 相关参数 set
| 参数| 说明 | 
|  ---  | --- | 
|max_coroutine  | 最大协程数 |
|stack_size | 协程初始化内存 默认2m | 
|log_level| 日志等级 经常配合trace_flags标签使用 |
 |trace_flags| 跟踪标签 |
|socket_connect_timeout |socket 连接超时时间
|socket_timeout socket |读写超时时间
|dns_cache_expire |swoole dns缓存时间
|dns_cache_capacity |swoole dns容量
##  defer
* 基于php __destruct 构建
* defer列表 是一个堆栈 Stack，先进后出
## exists
* 根据协程id 判断协程是否存在
* function Coroutine::exists(int $cid = 0) : bool
## getCid
* 获取当前协程id
## getPcid
* 协程之间并没有实质上的持续父子关系, 协程之间是相互隔离, 独立运作的
* 获取创建当前协程的协程id
## yield || suspend
* 让出协程执行权，挂起
* yield 之后必须有resume 否则协程将被挂起不执行
## resume
* 恢复协程执行
* function Swoole\Coroutine::resume(int $coroutineId);
## list || listCoroutine 
* 获取所有协程id
## status 
* 获取协程状态
## getBackTrace
* 获取协程函数调用栈
* function Coroutine::getBackTrace(int $cid=0, int $options=DEBUG_BACKTRACE_PROVIDE_OBJECT, int $limit=0) : array;

