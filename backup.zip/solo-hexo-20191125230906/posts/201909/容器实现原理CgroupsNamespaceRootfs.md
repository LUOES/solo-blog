title: 容器实现原理，Cgroups  Namespace,Rootfs
date: '2019-09-21 10:57:12'
updated: '2019-09-21 11:05:02'
tags: [docker]
permalink: /articles/2019/09/21/1569034631950.html
---
![](https://img.hacpai.com/bing/20180427.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 


# 容器实现原理
## Namespace（隔离）
* 系统资源隔离 
[参考链接: CSDN sdulish博客](https://blog.csdn.net/sdulibh/article/details/50442216)
## Cgroups (限制)  
* Linux Cgroups 的全称是 Linux Control Group。它最主要的作用，就是限制一个进程组能够使用的资源上限，包括 CPU、内存、磁盘、网络带宽等等。  
* 因为容器本身在os看了就是一个进程，进程之间会有资源争抢，所有要用linux内核的Cgroups进行管理  
[参考链接: IBM](https://www.ibm.com/developerworks/cn/linux/1506_cgroup/index.html)
## Rootfs
* 根文件系统，文件管理
[参考链接: CSDN leon1741博客](https://blog.csdn.net/LEON1741/article/details/78159754)
